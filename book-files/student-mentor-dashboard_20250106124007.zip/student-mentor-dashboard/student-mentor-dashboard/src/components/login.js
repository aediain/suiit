import React, { useState, useEffect } from 'react';
import { auth, database } from '../firebaseConfig'; // Firebase configuration
import {
  signInWithPopup,
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
} from 'firebase/auth';
import { getAuth, setPersistence, browserLocalPersistence, onAuthStateChanged } from "firebase/auth";
import { ref, set, get } from 'firebase/database';
import { useNavigate } from 'react-router-dom';
import googleLogo from './images/google-logo.png';

const errorMessages = {
  'auth/invalid-email': 'Please enter a valid email address.',
  'auth/user-disabled': 'This user has been disabled. Please contact support.',
  'auth/user-not-found': 'No account found with this email. Please sign up.',
  'auth/wrong-password': 'Incorrect password. Please try again.',
  'auth/email-already-in-use': 'An account with this email already exists. Please log in.',
  'auth/network-request-failed': 'Network error. Please check your internet connection.',
  default: 'An unexpected error occurred. Please try again.',
};

const getFriendlyErrorMessage = (error) => errorMessages[error.code] || errorMessages.default;

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showReset, setShowReset] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const provider = new GoogleAuthProvider();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    document.title = "Log In - Professional System";
    const authInstance = getAuth();

    setPersistence(authInstance, browserLocalPersistence)
      .then(() => {
        const unsubscribe = onAuthStateChanged(authInstance, (user) => {
          if (user) {
            // Check the user's 'isAdmin' status from Firebase Realtime Database
            const userRef = ref(database, `users/${user.uid}`);
            get(userRef)
              .then((snapshot) => {
                if (snapshot.exists()) {
                  const userData = snapshot.val();
                  const isAdmin = userData.isAdmin || false; // Default to false if 'isAdmin' does not exist
                  const redirectPage = isAdmin ? '/admin' : '/student';
                  navigate(redirectPage); // Redirect based on the user's role
                } else {
                  console.error("User data not found in the database.");
                }
              })
              .catch((error) => console.error("Error checking user role", error));

          }
          setLoading(false);
        });
        return unsubscribe;
      })
      .catch((error) => console.error("Error setting persistence", error));
  }, [navigate]);

  const handleSignInWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      // Fetch user data from Firebase to get 'isAdmin' status
      const userRef = ref(database, `users/${user.uid}`);
      get(userRef)
        .then((snapshot) => {
          if (snapshot.exists()) {
            const userData = snapshot.val();
            const isAdmin = userData.isAdmin || false;
            const redirectPage = isAdmin ? '/admin' : '/student';

            // Store user data in Firebase if it's a new user
            if (!userData) {
              set(userRef, {
                email: user.email,
                name: user.displayName,
                photoURL: user.photoURL,
                lastLogin: new Date().toISOString(),
                isAdmin: isAdmin,
              });
            }

            navigate(redirectPage);
          } else {
            // If the user does not exist in the database, set new user data
            set(userRef, {
              email: user.email,
              name: user.displayName,
              photoURL: user.photoURL,
              lastLogin: new Date().toISOString(),
              isAdmin: false, // Default to false for new users
            });
            navigate('/student');
          }
        })
        .catch((err) => {
          setError(getFriendlyErrorMessage(err));
        });
    } catch (err) {
      setError(getFriendlyErrorMessage(err));
    }
  };

  const handleEmailPasswordSignIn = async () => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Fetch user data from Firebase to get 'isAdmin' status
      const userRef = ref(database, `users/${user.uid}`);
      get(userRef)
        .then((snapshot) => {
          if (snapshot.exists()) {
            const userData = snapshot.val();
            const isAdmin = userData.isAdmin || false;
            const redirectPage = isAdmin ? '/admin' : '/student';

            navigate(redirectPage);
          } else {
            console.error("User data not found in the database.");
          }
        })
        .catch((error) => console.error("Error fetching user data", error));
    } catch (err) {
      setError(getFriendlyErrorMessage(err));
    }
  };

  const handleSignUp = async () => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Send email verification
      await sendEmailVerification(user);

      // Store user data in Firebase
      set(ref(database, `users/${user.uid}`), {
        email: user.email,
        createdOn: new Date().toISOString(),
        emailVerified: user.emailVerified,
        isAdmin: false, // Default to false for new users
      });

      setError('Sign-up successful! A verification email has been sent to your inbox.');
      setIsLogin(true);
      navigate('/login');
    } catch (err) {
      setError(getFriendlyErrorMessage(err));
    }
  };

  const handlePasswordReset = async () => {
    if (!email) {
      setError('Please enter your email address to reset your password.');
      return;
    }

    try {
      await sendPasswordResetEmail(auth, email);
      setError('Password reset email sent. Check your inbox.');
      setShowReset(false);  // Hide reset form and show login form again
    } catch (err) {
      setError(getFriendlyErrorMessage(err));
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="d-flex justify-content-center align-items-center vh-100 bg-gradient">
      <div className="card shadow-lg p-4" 
        style={{ 
          maxWidth: '400px', 
          width: '100%', 
          borderRadius: '12px', 
          backgroundColor: 'rgba(255, 255, 255, 0.95)', 
          boxShadow: '0 8px 20px rgba(0, 0, 0, 0.1)' 
        }}
      >
        <div className="text-center mb-4">
          <h1 className="mb-3" style={{ fontSize: '36px', fontWeight: 'bold', color: '#202124' }}>
            Welcome Back!
          </h1>
          <p className="text-muted" style={{ fontSize: '16px' }}>Sign in to continue</p>
        </div>

        {/* Google Sign-In Button */}
        <button
          onClick={handleSignInWithGoogle}
          className="btn btn-outline-danger w-100 d-flex align-items-center justify-content-center mb-4"
          style={{
            height: '50px',
            borderRadius: '8px',
            boxShadow: '0 5px 15px rgba(0, 0, 0, 0.15)',
            transition: 'box-shadow 0.3s ease-in-out'
          }}
          onMouseOver={(e) => (e.currentTarget.style.boxShadow = '0 10px 25px rgba(0, 0, 0, 0.2)')}
          onMouseOut={(e) => (e.currentTarget.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.15)')}
        >
          <img src={googleLogo} alt="Google Logo" style={{ width: '20px', marginRight: '10px' }} />
          Sign in with Google
        </button>

        {/* Or divider */}
        <div className="text-center mb-4">
          <p className="text-muted mb-0">or</p>
        </div>

        <form>
          <div className="form-group mb-3">
            <label htmlFor="email" className="sr-only">Email</label>
            <div className="input-group">
              <div className="input-group-prepend">
                <span className="input-group-text bg-light"><i className="bi bi-envelope"></i></span>
              </div>
              <input
                type="email"
                className="form-control"
                id="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                style={{ borderRadius: '8px', boxShadow: '0 5px 10px rgba(0, 0, 0, 0.15)' }}
              />
            </div>
          </div>

          {!showReset && (
            <div className="form-group mb-3">
              <label htmlFor="password" className="sr-only">Password</label>
              <div className="input-group">
                <div className="input-group-prepend">
                  <span className="input-group-text bg-light"><i className="bi bi-lock"></i></span>
                </div>
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  style={{ borderRadius: '8px', boxShadow: '0 5px 10px rgba(0, 0, 0, 0.15)' }}
                />
              </div>
            </div>
          )}

          <div>
            {showReset ? (
              <button
                onClick={handlePasswordReset}
                className="btn btn-primary w-100 py-2"
                style={{ height: '50px' }}
              >
                <i className="bi bi-key"></i> Reset Password
              </button>
            ) : (
              <button
                onClick={isLogin ? handleEmailPasswordSignIn : handleSignUp}
                className="btn btn-primary w-100 py-2"
                style={{ height: '50px' }}
              >
                {isLogin ? <i className="bi bi-box-arrow-in-right"></i> : <i className="bi bi-person"></i>} {isLogin ? 'Login' : 'Sign Up'}
              </button>
            )}
          </div>
        </form>

        <div className="text-center mt-3">
          <button onClick={() => setIsLogin(!isLogin)} className="btn btn-link">
            {isLogin ? 'Create an account' : 'Already have an account? Login'}
          </button>
          <br />
          {!isLogin && (
            <button onClick={() => setShowReset(!showReset)} className="btn btn-link">
              {showReset ? 'Back to Login' : 'Forgot Password?'}
            </button>
          )}
        </div>

        {error && <p className="text-danger text-center mt-3">{error}</p>}
      </div>
    </div>
  );
};

export default LoginPage;
