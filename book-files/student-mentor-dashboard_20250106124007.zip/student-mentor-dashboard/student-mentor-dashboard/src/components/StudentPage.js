import React, { useState, useEffect } from 'react';
import { Container, Row, Col, ListGroup, Card, Button, Modal, Form } from 'react-bootstrap';
import { ref, get, push,  } from 'firebase/database';
import { database } from '../firebaseConfig';
import { getAuth, onAuthStateChanged ,signOut} from 'firebase/auth'; // Import Firebase Auth
import { useNavigate } from 'react-router-dom';

const StudentPage = () => {
  const [sharedData, setSharedData] = useState([]);
  const [selectedData, setSelectedData] = useState(null);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [ShowDetailsModal, setShowDetailsModal] = useState(false);
  const [showAnswerModal, setShowAnswerModal] = useState(false);
  const [answerFile, setAnswerFile] = useState(null);
  const [feedback, setFeedback] = useState('');
  const [email, setEmail] = useState(''); // Assuming you want to take email input for user
  const auth = getAuth(); // Initialize Firebase Auth
  const [showUpdates, setShowUpdates] = useState(true); 
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [hasUploadedAnswer, setHasUploadedAnswer] = useState(false); // State to track if user uploaded answer

  useEffect(() => {
    const user = auth.currentUser;
    if (user) {
         setUser(auth.currentUser)
    }
  }, [auth]);


  
  useEffect(() => {
    // Fetch shared data from Firebase Realtime Database
    const fetchSharedData = async () => {
      try {
        const snapshot = await get(ref(database, 'shared_data/'));
        const data = snapshot.val();
        const dataList = [];

        for (let id in data) {
          dataList.push({ id, ...data[id] });
        }

        setSharedData(dataList);
      } catch (error) {
        console.error('Error fetching data from Firebase:', error);
      }
    };

    fetchSharedData();
    

    // Listen for user authentication state
    onAuthStateChanged(auth, (user) => {
      if (user) {
        setEmail(user.email); // Set authenticated user's email
      } else {
        setEmail(''); // Clear email if no user is signed in
      }
    });
  }, [auth]); // Dependency on auth state

 
  const handleShowDetails = (data) => {
    setSelectedData(data);
    // Check if the user has already uploaded an answer for this selected data
    const answerRef = ref(database, `shared_data/${data.id}/answers/`);
    get(answerRef).then((snapshot) => {
      const answers = snapshot.val() || {};
      const userAnswerExists = Object.values(answers).some(answer => answer.email === email);
      setHasUploadedAnswer(userAnswerExists); // Set the state to true if answer exists
    });
  };
  

  const handleShowQuestionModal = () => {
    setShowQuestionModal(true);
  };
  const handleShowDetailsModal = () => {
    setShowDetailsModal(true);
  };

  const handleCloseDetailsModal = () => {
    setShowDetailsModal(false);
  };
  const handleCloseQuestionModal = () => {
    setShowQuestionModal(false);
  };

  const handleShowAnswerModal = () => {
    setShowAnswerModal(true);
  };

  const handleCloseAnswerModal = () => {
    setShowAnswerModal(false);
  };

  const handleAnswerFileChange = (e) => {
    const file = e.target.files[0];
    setAnswerFile(file);
  };

  const handleFeedbackChange = (e) => {
    setFeedback(e.target.value);
  };

  const uploadAnswerFile = async () => {
    if (!answerFile || !email || !selectedData) {
      console.error('Missing file, email, or shared_data ID');
      return;
    }

    try {
      // Check if the user already uploaded an answer for this shared_data ID
      const answerRef = ref(database, `shared_data/${selectedData.id}/answers/`);
      const snapshot = await get(answerRef);
      const answers = snapshot.val() || {};

      const userAnswerExists = Object.values(answers).some(answer => answer.email === email);

      if (userAnswerExists) {
        console.error('You have already uploaded an answer for this shared_data.');
        return;
      }

      // Convert the file to base64 to upload to GitHub
      const fileData = await toBase64(answerFile);

      // Upload to GitHub
      const response = await fetch(`https://api.github.com/repos/amreshbhuya/server/contents/answers/${answerFile.name}`, {
        method: 'PUT',
        headers: {
          'Authorization': `token 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`,
          'Accept': 'application/vnd.github.v3+json',
        },
        body: JSON.stringify({
          message: `Upload Answer Paper: ${answerFile.name}`,
          content: fileData,
        }),
      });

      if (!response.ok) {
        throw new Error('Error uploading answer file');
      }

      const fileLink = `https://raw.githubusercontent.com/amreshbhuya/server/main/answers/${answerFile.name}`; // Constructing the URL for the uploaded file

      // Save the file link and associated data in Firebase
      await push(ref(database, `shared_data/${selectedData.id}/answers/`), {
        fileLink,
        email,
        uploadedAt: new Date().toISOString(),
      });

      console.log('Answer file uploaded successfully!');
      setAnswerFile(null);
      setShowAnswerModal(false);
    } catch (err) {
      console.error('Error uploading answer file:', err);
    }
  };

  const uploadFeedback = async () => {
    if (!feedback || !email || !selectedData) {
      console.error('Missing feedback, email, or shared_data ID');
      return;
    }

    try {
      const feedbackData = {
        feedback,
        email,
        submittedAt: new Date().toISOString(),
      };

      const feedbackRef = ref(database, `shared_data/${selectedData.id}/feedback/`);
      await push(feedbackRef, feedbackData);

      console.log('Feedback submitted successfully!');
      setFeedback('');
    } catch (err) {
      console.error('Error submitting feedback:', err);
    }
  };

  const toBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result.split(',')[1]);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };
  return (
    <div className="student-page">
    <Container fluid style={{ marginTop: '80px', padding: '0 15px' }}>
      <h1 className="mt-4 text-center text-success">
        <i className="bi bi-arrow-repeat me-2"></i> Shared Updates
        {user ? (
          <a
            href="/student"
            className="position-fixed bottom-0 start-0 mb-1 ms-1 d-flex align-items-center p-2 text-dark text-decoration-none"
            style={{ zIndex: 1050, backgroundColor: 'transparent' }}
          >
            <img
              src={user.photoURL}
              alt={user.email}
              className="rounded-circle me-2"
              style={{ height: '50px', width: '50px', boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)' }}
            />
            {user.displayName || user.email}
          </a>
        ) : null}
      </h1>
      <p className="text-center text-muted">Click on any item to view more details.</p>
  
      {/* Responsive toggle button */}
      <div className="d-block d-md-none text-center mb-3">
        <Button
          variant="info"
          onClick={() => setShowUpdates(!showUpdates)}
          className="w-100 py-2 rounded-3 shadow-sm"
          style={{ transition: '0.3s' }}
        >
          <i className="bi bi-file-earmark-text me-2"></i> Show Available Updates
        </Button>
      </div>
  
      <Row className="g-4">
        {/* Left Section: List of Data */}
        <Col xs={12} md={4} className={`${showUpdates ? '' : 'd-none'} d-md-block`}>
          <Card className="shadow-lg border-0 rounded-3 sticky-top" style={{ top: '80px' }}>
            <Card.Body>
              <h5 className="text-success">
                <i className="bi bi-file-earmark-text me-2"></i> Available Updates
              </h5>
              <ListGroup>
                {sharedData.map((data) => (
                  <ListGroup.Item
                    key={data.id}
                    action
                    onClick={() => handleShowDetails(data)}
                    className="mb-3 p-3 rounded-3 shadow-sm bg-light hover-shadow"
                    style={{ cursor: 'pointer', transition: '0.3s' }}
                  >
                    <i className="bi bi-file-earmark-text me-2"></i>
                    {data.title}
                  </ListGroup.Item>
                ))}
              </ListGroup>
            </Card.Body>
          </Card>
        </Col>
  
        {/* Right Section: Data Details */}
        <Col xs={12} md={8}>
          {selectedData ? (
            <Card className="shadow-lg border-0 rounded-3">
              <Card.Body>
                <h5 className="text-success">
                  <i className="bi bi-file-earmark-richtext me-2"></i>
                  {selectedData.title}
                </h5>
  
                {/* Video Link Section */}
                <div className="mb-3">
                  <h6>
                    <strong>Video/Link:</strong>{' '}
                    <i className="bi bi-link-45deg"></i>
                  </h6>
                  {selectedData.videoLink ? (
                    selectedData.videoLink.endsWith('.pdf') || selectedData.videoLink.endsWith('.doc') || selectedData.videoLink.endsWith('.docx') ? (
                      <iframe
                        src={selectedData.videoLink}
                        width="100%"
                        height="400px"
                        frameBorder="0"
                        title="Document"
                        className="rounded-3 shadow-sm"
                      ></iframe>
                    ) : selectedData.videoLink.includes('youtube.com') || selectedData.videoLink.includes('youtu.be') ? (
                      <iframe
                        src={selectedData.videoLink.includes('watch?v=') ? selectedData.videoLink.replace('watch?v=', 'embed/') : selectedData.videoLink.replace('youtu.be/', 'www.youtube.com/embed/')}
                        width="100%"
                        height="400px"
                        frameBorder="0"
                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        title="YouTube Video"
                        className="rounded-3 shadow-sm"
                      ></iframe>
                    ) : (
                      <iframe
                        width="100%"
                        height="400px"
                        src={selectedData.videoLink}
                        frameBorder="0"
                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        title="Video"
                        className="rounded-3 shadow-sm"
                      ></iframe>
                    )
                  ) : (
                    <p>No video or link available.</p>
                  )}
                </div>
  
                {/* Description Section */}
                <div className="mb-3">
                  <h6>
                    <strong>Description:</strong>{' '}
                    <i className="bi bi-info-circle-fill"></i>
                  </h6>
                  <p>{selectedData.description}</p>
                </div>
  
                {/* Question Paper Link Button */}
                <div className="row">
  {/* View Question Paper Button */}
  <div className="col-md-6 mb-3">
    <Button
      onClick={handleShowQuestionModal}
      className="w-100 py-2 rounded-3 text-white"
      style={{
        backgroundColor: '#1A73E8', // Google Blue color
        borderColor: '#1A73E8', // Matching border color
        transition: '0.3s', // Smooth transition on hover
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)', // Soft shadow for depth
        fontWeight: '500', // Medium font weight for a modern feel
      }}
    >
      <i className="bi bi-file-earmark-pdf me-2" style={{ fontSize: '1.2rem' }}></i>
      View Question Paper
    </Button>
  </div>

  {/* View Details Report Button */}
  <div className="col-md-6 mb-3">
    <Button
      onClick={handleShowDetailsModal}
      className="w-100 py-2 rounded-3 text-white"
      style={{
        backgroundColor: '#FFB300', // Google Yellow color
        borderColor: '#FFB300', // Matching border color
        transition: '0.3s', // Smooth transition on hover
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)', // Soft shadow for depth
        fontWeight: '500', // Medium font weight
      }}
    >
      <i className="bi bi-file-earmark-text me-2" style={{ fontSize: '1.2rem' }}></i>
      View Video Details Report
    </Button>
  </div>
</div>

  
                {/* Answer Paper Upload Button */}
                {/* Conditional Rendering of Upload Button */}
                {!hasUploadedAnswer && (
  <Button
    variant="primary"
    onClick={handleShowAnswerModal}
    className="w-100"
  >
    <i className="bi bi-cloud-upload"></i> Upload Answer Paper
  </Button>
)}
{hasUploadedAnswer && <p>Your answer has been uploaded.</p>}


  
                {/* Evaluated Answers Section - Filtered by User Email */}
                <div className="mb-3">
                  <h6>
                    <strong>Evaluated Answers:</strong>{' '}
                    <i className="bi bi-journal-check"></i>
                  </h6>
                  <ListGroup>
                    {selectedData.answers &&
                      Object.values(selectedData.answers)
                        .filter((answer) => answer.email === email) // Filter answers by user's email
                        .map((answer, index) => (
                          <ListGroup.Item
  key={index}
  className="mb-4 p-4 rounded-3 shadow-lg bg-white hover-shadow"
  style={{
    borderLeft: '5px solid #007bff', // Accent color (blue) on the left side for a stylish touch
    transition: 'all 0.3s ease', // Smooth transition for hover effect
  }}
>
  <div className="d-flex justify-content-between align-items-center mb-3">
    <h5 className="text-dark fw-bold">
      <i className="bi bi-person-circle me-2"></i> {answer.email}
    </h5>
    <small className="text-muted">
      <i className="bi bi-calendar-check me-2"></i>
      Uploaded at: {new Date(answer.uploadedAt).toLocaleString()}
    </small>
  </div>
  
  <div>
    {/* Evaluated Answer Section */}
    <div className="mb-3">
      <h6 className="text-primary d-flex align-items-center">
        <i className="bi bi-file-earmark-lock me-2"></i> <span className="fw-semibold">Evaluated Answer:</span>
      </h6>
      {answer.evaluated_answer && answer.evaluated_answer.fileLink ? (
        <a
          href={answer.evaluated_answer.fileLink}
          target="_blank"
          rel="noopener noreferrer"
          className="btn btn-outline-primary btn-sm px-4 py-2"
          style={{ textDecoration: 'none' }}
        >
          View Evaluated Answer
          <span className="fw-bold ms-2"> (Evaluated By: {answer.evaluated_answer.evaluator})</span>
        </a>
      ) : (
        <span className="text-danger">Evaluated Answer Report not available</span>
      )}
    </div>
    
    {/* Details Report Section */}
    <div className="mb-3">
      <h6 className="text-info d-flex align-items-center">
        <i className="bi bi-file-earmark-text me-2"></i> <span className="fw-semibold">Details Report:</span>
      </h6>
      {answer.details_report && answer.details_report.fileLink ? (
        <a
          href={answer.details_report.fileLink}
          target="_blank"
          rel="noopener noreferrer"
          className="btn btn-outline-info btn-sm px-4 py-2"
          style={{ textDecoration: 'none' }}
        >
          View Details Report
          <span className="fw-bold ms-2"> (Evaluated By: {answer.evaluated_answer.evaluator})</span>
        </a>
      ) : (
        <span className="text-warning">Details Report not available</span>
      )}
    </div>
  </div>
</ListGroup.Item>

                        ))}
                  </ListGroup>
                </div>
               
  
                {/* Feedback Section */}
                <div className="mb-3">
                  <h6>
                    <strong>Give Feedback:</strong>{' '}
                    <i className="bi bi-pencil-square"></i>
                  </h6>
                  <Form>
                    <Form.Group controlId="formFeedback">
                      <Form.Control
                        as="textarea"
                        rows={3}
                        placeholder="Provide your feedback here..."
                        value={feedback}
                        onChange={handleFeedbackChange}
                        className="rounded-3"
                        style={{
                          boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
                          transition: '0.3s',
                        }}
                      />
                    </Form.Group>
                    <Button variant="success" onClick={uploadFeedback} className="mt-2 w-100 py-2 rounded-3">
                      <i className="bi bi-check-circle me-2"></i> Submit Feedback
                    </Button>
                  </Form>
                </div>
              </Card.Body>
            </Card>
          ) : (
            <Card className="shadow-sm">
              <Card.Body>
                <p>Select an item from the left to view its details.</p>
              </Card.Body>
            </Card>
          )}
        </Col>
      </Row>
    </Container>
  
    {/* Modal for Question Paper */}
    <Modal show={showQuestionModal} onHide={handleCloseQuestionModal} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>
          <i className="bi bi-file-earmark-pdf me-2"></i> Question Paper
        </Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="mb-3">
          <h6>
            <strong>Question Paper/Link:</strong>{' '}
            <i className="bi bi-link-45deg"></i>
          </h6>
          {selectedData && selectedData.questionPaperLink ? (
            selectedData.questionPaperLink.endsWith('.pdf') ||
            selectedData.questionPaperLink.endsWith('.doc') ||
            selectedData.questionPaperLink.endsWith('.docx') ? (
              <iframe
                src={selectedData.questionPaperLink}
                width="100%"
                height="600px"
                frameBorder="0"
                title="Document"
                className="rounded-3 shadow-sm"
                allowFullScreen
              ></iframe>
            ) : selectedData.questionPaperLink.includes('youtube.com') ||
              selectedData.questionPaperLink.includes('youtu.be') ? (
              <iframe
                src={
                  selectedData.questionPaperLink.includes('watch?v=')
                    ? selectedData.questionPaperLink.replace('watch?v=', 'embed/')
                    : selectedData.questionPaperLink.replace('youtu.be/', 'www.youtube.com/embed/')
                }
                width="100%"
                height="600px"
                frameBorder="0"
                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title="YouTube Video"
                className="rounded-3 shadow-sm"
              ></iframe>
            ) : (
              <iframe
                width="100%"
                height="600px"
                src={selectedData ? selectedData.questionPaperLink : '#'}
                frameBorder="0"
                allowFullScreen
                title="Question Paper"
                className="rounded-3 shadow-sm"
              ></iframe>
            )
          ) : (
            <p>No question paper or link available.</p>
          )}
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleCloseQuestionModal}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  

    <Modal show={ShowDetailsModal} onHide={handleCloseDetailsModal} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>
          <i className="bi bi-file-earmark-pdf me-2"></i> Question Paper
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="mb-3">
          <h6>
            <strong>Question Paper/Link:</strong>{' '}
            <i className="bi bi-link-45deg"></i>
          </h6>
          {selectedData && selectedData.detailsReportLink
 ? (
            selectedData.detailsReportLink.endsWith('.pdf') ||
            selectedData.detailsReportLink.endsWith('.doc') ||
            selectedData.detailsReportLink.endsWith('.docx') ? (
              <iframe
                src={selectedData.detailsReportLink}
                width="100%"
                height="600px"
                frameBorder="0"
                title="Document"
                className="rounded-3 shadow-sm"
                allowFullScreen
              ></iframe>
            ) : selectedData.detailsReportLink.includes('youtube.com') ||
              selectedData.detailsReportLink.includes('youtu.be') ? (
              <iframe
                src={
                  selectedData.detailsReportLink.includes('watch?v=')
                    ? selectedData.detailsReportLink.replace('watch?v=', 'embed/')
                    : selectedData.detailsReportLink.replace('youtu.be/', 'www.youtube.com/embed/')
                }
                width="100%"
                height="600px"
                frameBorder="0"
                allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title="YouTube Video"
                className="rounded-3 shadow-sm"
              ></iframe>
            ) : (
              <iframe
                width="100%"
                height="600px"
                src={selectedData ? selectedData.detailsReportLink : '#'}
                frameBorder="0"
                allowFullScreen
                title="Question Paper"
                className="rounded-3 shadow-sm"
              ></iframe>
            )
          ) : (
            <p>No question paper or link available.</p>
          )}
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleCloseDetailsModal}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>



    {/* Logout Button */}
    <Button
      variant="danger"
      onClick={handleLogout}
      style={{
        position: 'absolute',
        top: '20px',
        right: '20px',
        zIndex: 10,
      }}
    >
      <i className="bi bi-box-arrow-right"></i> Log Out
    </Button>
  
    {/* Modal for Answer Paper Upload */}
    <Modal show={showAnswerModal} onHide={handleCloseAnswerModal} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>
          <i className="bi bi-cloud-upload me-2"></i> Upload Answer Paper
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group controlId="formFile">
            <Form.Control
              type="file"
              onChange={handleAnswerFileChange}
              className="rounded-3"
              style={{ boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}
            />
          </Form.Group>
          <Form.Group controlId="formEmail" className="mt-3">
            <Form.Control
              type="email"
              placeholder="Enter your email"
              value={email}
              readOnly
              className="rounded-3"
              style={{ boxShadow: '0 2px 10px rgba(0,0,0,0.1)' }}
            />
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleCloseAnswerModal}>
          Close
        </Button>
        <Button variant="success" onClick={uploadAnswerFile}>
          Upload
        </Button>
      </Modal.Footer>
    </Modal>
    
  </div>
  
  );
};

export default StudentPage;
