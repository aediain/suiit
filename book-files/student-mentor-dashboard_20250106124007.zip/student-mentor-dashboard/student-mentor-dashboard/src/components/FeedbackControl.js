import React, { useState, useEffect } from 'react';
import { Container, Table, Button } from 'react-bootstrap';
import { ref, get, remove } from 'firebase/database';
import { database } from '../firebaseConfig';

const FeedbackControlPage = () => {
  const [feedbackData, setFeedbackData] = useState([]);

  useEffect(() => {
    // Fetch feedback data from Firebase Realtime Database
    const fetchFeedbackData = async () => {
      try {
        const snapshot = await get(ref(database, 'shared_data/'));
        const data = snapshot.val();
        const feedbackList = [];

        // Iterate through each shared_data item and collect feedback
        for (let id in data) {
          const feedbackRef = ref(database, `shared_data/${id}/feedback/`);
          const feedbackSnapshot = await get(feedbackRef);
          const feedback = feedbackSnapshot.val();

          if (feedback) {
            for (let feedbackId in feedback) {
              feedbackList.push({ sharedDataId: id, feedbackId, ...feedback[feedbackId] });
            }
          }
        }

        setFeedbackData(feedbackList);
      } catch (error) {
        console.error('Error fetching feedback data from Firebase:', error);
      }
    };

    fetchFeedbackData();
  }, []);

  const handleDeleteFeedback = async (sharedDataId, feedbackId) => {
    try {
      await remove(ref(database, `shared_data/${sharedDataId}/feedback/${feedbackId}`));
      setFeedbackData(feedbackData.filter(feedback => feedback.feedbackId !== feedbackId));
    } catch (error) {
      console.error('Error deleting feedback:', error);
    }
  };

  return (
    <Container style={{ marginTop: '80px' }}>
      <h1 className="mt-4 text-center text-success">Feedback Control Page</h1>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Shared Data ID</th>
            <th>Email</th>
            <th>Feedback</th>
            <th>Submitted At</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {feedbackData.map((feedback, index) => (
            <tr key={index}>
              <td>{feedback.sharedDataId}</td>
              <td>{feedback.email}</td>
              <td>{feedback.feedback}</td>
              <td>{new Date(feedback.submittedAt).toLocaleString()}</td>
              <td>
                <Button 
                  variant="danger" 
                  size="sm" 
                  onClick={() => handleDeleteFeedback(feedback.sharedDataId, feedback.feedbackId)}
                >
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  );
};

export default FeedbackControlPage;
