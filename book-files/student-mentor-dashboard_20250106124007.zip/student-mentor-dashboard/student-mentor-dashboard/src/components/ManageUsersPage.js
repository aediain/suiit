import React, { useState, useEffect } from 'react';
import { database } from '../firebaseConfig'; // Firebase configuration
import { ref, onValue, remove, update } from 'firebase/database';

const ManageUserPage = () => {
  const [users, setUsers] = useState([]);
  const [editingUserId, setEditingUserId] = useState(null);
  const [editedUserData, setEditedUserData] = useState({});

  // Fetch users from the database
  useEffect(() => {
    const usersRef = ref(database, 'users/');
    const unsubscribe = onValue(usersRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const userArray = Object.keys(data).map((id) => ({ id, ...data[id] }));
        setUsers(userArray);
      } else {
        setUsers([]);
      }
    });

    // Cleanup the Firebase listener on component unmount
    return () => {
      unsubscribe();
    };
  }, []);

  // Delete user
  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      remove(ref(database, `users/${id}`))
        .then(() => {
          alert('User deleted successfully.');
        })
        .catch((error) => {
          console.error('Error deleting user:', error);
        });
    }
  };

  // Start editing user
  const handleEdit = (user) => {
    setEditingUserId(user.id);
    setEditedUserData(user); // Initialize edited user data
  };

  // Cancel editing
  const handleCancel = () => {
    setEditingUserId(null);
    setEditedUserData({});
  };

  // Save edited user data
  const handleSave = () => {
    update(ref(database, `users/${editingUserId}`), editedUserData)
      .then(() => {
        alert('User updated successfully.');
        setEditingUserId(null);
      })
      .catch((error) => {
        console.error('Error updating user:', error);
      });
  };

  // Handle field changes in the edit form
  const handleChange = (field, value) => {
    setEditedUserData((prevData) => ({
      ...prevData,
      [field]: value,
    }));
  };

  return (
    <div className="container">
      <h2 className="my-4">Manage Users</h2>
      {users.length > 0 ? (
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Image</th>
              <th>Email</th>
              <th>Name</th>
              <th>Last Login</th>
              <th>Is Admin</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                {/* User Image */}
                <td>
                  <img
                    src={user.photoURL || 'https://via.placeholder.com/50'}
                    alt="User"
                    className="img-thumbnail"
                    style={{ width: '50px', height: '50px', objectFit: 'cover' }}
                  />
                </td>

                {/* Email (Inline Edit) */}
                <td>
                  {editingUserId === user.id ? (
                    <input
                      type="email"
                      className="form-control form-control-sm"
                      value={editedUserData.email || ''}
                      onChange={(e) => handleChange('email', e.target.value)}
                    />
                  ) : (
                    user.email || 'N/A'
                  )}
                </td>

                {/* Name (Inline Edit) */}
                <td>
                  {editingUserId === user.id ? (
                    <input
                      type="text"
                      className="form-control form-control-sm"
                      value={editedUserData.name || ''}
                      onChange={(e) => handleChange('name', e.target.value)}
                    />
                  ) : (
                    user.name || 'N/A'
                  )}
                </td>

                {/* Last Login */}
                <td>
                  {user.lastLogin
                    ? new Date(user.lastLogin).toLocaleString()
                    : 'N/A'}
                </td>

                {/* Is Admin (Inline Edit) */}
                <td>
                  {editingUserId === user.id ? (
                    <select
                      className="form-control form-control-sm"
                      value={editedUserData.isAdmin || false}
                      onChange={(e) => handleChange('isAdmin', e.target.value === 'true')}
                    >
                      <option value="false">No</option>
                      <option value="true">Yes</option>
                    </select>
                  ) : (
                    <span>{user.isAdmin ? 'Yes' : 'No'}</span>
                  )}
                </td>

                {/* Actions */}
                <td>
                  {editingUserId === user.id ? (
                    <>
                      <button
                        onClick={handleSave}
                        className="btn btn-success btn-sm mx-1"
                      >
                        Save
                      </button>
                      <button
                        onClick={handleCancel}
                        className="btn btn-secondary btn-sm mx-1"
                      >
                        Cancel
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => handleEdit(user)}
                        className="btn btn-primary btn-sm mx-1"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(user.id)}
                        className="btn btn-danger btn-sm mx-1"
                      >
                        Delete
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p className="text-center text-muted">No users found.</p>
      )}
    </div>
  );
};

export default ManageUserPage;
