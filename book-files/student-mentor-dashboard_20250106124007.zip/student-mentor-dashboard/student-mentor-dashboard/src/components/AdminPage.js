import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { signOut } from 'firebase/auth';
import { auth } from '../firebaseConfig'; // Firebase configuration
import { Navbar, Nav, NavDropdown, Container, Button, Card } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

const AdminPage = () => {
  const [adminName, setAdminName] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    document.title = "Admin Dashboard - Catching Center of India";

    // Simulating fetching admin name from auth or database
    const fetchAdminName = async () => {
      const user = auth.currentUser;
      if (user) {
        setAdminName(user.displayName || "Admin");
      }
    };

    fetchAdminName();
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  return (
    <div className="admin-page">
      {/* Navbar */}
      <Navbar bg="success" variant="dark" expand="lg" fixed="top">
        <Container>
          <Navbar.Brand href="/admin" style={{ fontWeight: 'bold' }}>
            <i className="bi bi-house"></i> Admin Dashboard
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="navbarNav" />
          <Navbar.Collapse id="navbarNav">
            <Nav className="ms-auto">
              <NavDropdown
                title={
                  <>
                    <i className="bi bi-person-circle"></i> {adminName || 'Admin'}
                  </>
                }
                id="admin-dropdown"
              >
                <NavDropdown.Item href="/admin/profile">
                  <i className="bi bi-person"></i> Profile
                </NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item onClick={handleLogout}>
                  <i className="bi bi-box-arrow-right"></i> Logout
                </NavDropdown.Item>
              </NavDropdown>
              <Nav.Link href="/admin/users" className="text-white fw-medium">
                <i className="bi bi-people"></i> Show Users
              </Nav.Link>
              <Nav.Link href="/admin/share" className="text-white fw-medium">
                <i className="bi bi-share"></i> Share to Users
              </Nav.Link>
              <Nav.Link href="/admin/control" className="text-white fw-medium">
                <i className="bi bi-gear"></i> Control Panel
              </Nav.Link>
              <Nav.Link href="/admin/FeedbackControl" className="text-white fw-medium">
                <i className="bi bi-chat-left-text"></i> Feedback Control
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Content */}
      <Container style={{ marginTop: '80px' }}>
        <h1 className="mt-4 text-center text-success">Welcome to the Admin Dashboard</h1>
        <p className="text-center text-muted">
          Manage all users, share updates, and control access from one place.
        </p>

        <div className="row mt-5">
          <div className="col-md-6">
            <Card className="shadow-sm border-success">
              <Card.Body>
                <h5 className="card-title text-success">
                  <i className="bi bi-people-fill"></i> User Management
                </h5>
                <p className="card-text">
                  View, manage, and control user access and details.
                </p>
                <Button variant="success" href="/admin/users" className="text-white">
                  Manage Users
                </Button>
              </Card.Body>
            </Card>
          </div>

          <div className="col-md-6">
            <Card className="shadow-sm border-success">
              <Card.Body>
                <h5 className="card-title text-success">
                  <i className="bi bi-share"></i> Share Updates
                </h5>
                <p className="card-text">
                  Share important updates and resources with all users.
                </p>
                <Button variant="success" href="/admin/share" className="text-white">
                  Share Now
                </Button>
              </Card.Body>
            </Card>
          </div>
        </div>

        <div className="row mt-4">
          <div className="col-md-6">
            <Card className="shadow-sm border-success">
              <Card.Body>
                <h5 className="card-title text-success">
                  <i className="bi bi-gear"></i> Control Panel
                </h5>
                <p className="card-text">
                  Access advanced settings and controls.
                </p>
                <Button variant="success" href="/admin/control" className="text-white">
                  Go to Control Panel
                </Button>
              </Card.Body>
            </Card>
          </div>

          <div className="col-md-6">
            <Card className="shadow-sm border-success">
              <Card.Body>
                <h5 className="card-title text-success">
                  <i className="bi bi-chat-left-text"></i> Feedback Control
                </h5>
                <p className="card-text">
                  View and manage all user feedback.
                </p>
                <Button variant="success" href="/admin/FeedbackControl" className="text-white">
                  View Feedback
                </Button>
              </Card.Body>
            </Card>
          </div>
        </div>
      </Container>
    </div>
  );
};

export default AdminPage;
