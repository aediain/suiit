import React, { useState, useEffect } from 'react';
import { Button, Container, Form, Alert, Table } from 'react-bootstrap';
import { ref, push, set, onValue, remove, update } from 'firebase/database';
import { database } from '../firebaseConfig';

const SharePage = () => {
  const [title, setTitle] = useState('');
  const [videoLink, setVideoLink] = useState('');
  const [questionPaperLink, setQuestionPaperLink] = useState('');
  const [description, setDescription] = useState('');
  const [detailsReportLink, setDetailsReportLink] = useState(''); // New state for details report link
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [sharedData, setSharedData] = useState([]);
  const [editData, setEditData] = useState(null); // State for editing data

  useEffect(() => {
    const sharedDataRef = ref(database, 'shared_data/');
    const unsubscribe = onValue(sharedDataRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const formattedData = Object.keys(data).map((key) => ({
          id: key,
          ...data[key],
        }));
        setSharedData(formattedData);
      } else {
        setSharedData([]);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const sharedDataRef = ref(database, 'shared_data/');
      const newDataRef = push(sharedDataRef);

      await set(newDataRef, {
        title,
        videoLink,
        questionPaperLink,
        description,
        detailsReportLink, // New field to be saved in Firebase
        timestamp: new Date().toISOString(),
      });

      // Reset state after successful submission
      setTitle('');
      setVideoLink('');
      setQuestionPaperLink('');
      setDescription('');
      setDetailsReportLink(''); // Clear the new input field

      alert('Data shared successfully!');
    } catch (error) {
      console.error('Error sharing data:', error);
      setError('There was an error sharing the data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (data) => {
    setEditData(data);
    setTitle(data.title);
    setVideoLink(data.videoLink);
    setQuestionPaperLink(data.questionPaperLink);
    setDescription(data.description);
    setDetailsReportLink(data.detailsReportLink); // Pre-fill the edit form with the current details report link
  };

  const handleUpdate = async () => {
    setLoading(true);
    setError('');

    try {
      const dataRef = ref(database, `shared_data/${editData.id}`);
      await update(dataRef, {
        title,
        videoLink,
        questionPaperLink,
        description,
        detailsReportLink, // Include the new field in the update
      });

      setEditData(null);
      setTitle('');
      setVideoLink('');
      setQuestionPaperLink('');
      setDescription('');
      setDetailsReportLink(''); // Clear the new field after updating

      alert('Data updated successfully!');
    } catch (error) {
      console.error('Error updating data:', error);
      setError('There was an error updating the data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      const dataRef = ref(database, `shared_data/${id}`);
      await remove(dataRef);
      alert('Data deleted successfully!');
    } catch (error) {
      console.error('Error deleting data:', error);
      alert('There was an error deleting the data.');
    }
  };

  return (
    <div className="share-page">
      <Container style={{ marginTop: '80px' }}>
        <h1 className="mt-4 text-center text-success">Share Updates</h1>
        <p className="text-center text-muted">Share important updates and resources with users.</p>

        {error && <Alert variant="danger">{error}</Alert>}

        {editData ? (
          <Form onSubmit={handleUpdate} className="mt-5">
            <Form.Group className="mb-3" controlId="formTitle">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formVideoLink">
              <Form.Label>Video Link</Form.Label>
              <Form.Control
                type="url"
                placeholder="Enter video link"
                value={videoLink}
                onChange={(e) => setVideoLink(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formQuestionPaperLink">
              <Form.Label>Question Paper Link</Form.Label>
              <Form.Control
                type="url"
                placeholder="Enter question paper link"
                value={questionPaperLink}
                onChange={(e) => setQuestionPaperLink(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formDescription">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Enter description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formDetailsReportLink">
              <Form.Label>Details Report Link</Form.Label>
              <Form.Control
                type="url"
                placeholder="Enter details report link"
                value={detailsReportLink}
                onChange={(e) => setDetailsReportLink(e.target.value)}
                required
              />
            </Form.Group>

            <Button variant="success" type="submit" disabled={loading}>
              {loading ? 'Updating...' : 'Update'}
            </Button>
          </Form>
        ) : (
          <Form onSubmit={handleSubmit} className="mt-5">
            <Form.Group className="mb-3" controlId="formTitle">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formVideoLink">
              <Form.Label>Video Link</Form.Label>
              <Form.Control
                type="url"
                placeholder="Enter video link"
                value={videoLink}
                onChange={(e) => setVideoLink(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formQuestionPaperLink">
              <Form.Label>Question Paper Link</Form.Label>
              <Form.Control
                type="url"
                placeholder="Enter question paper link"
                value={questionPaperLink}
                onChange={(e) => setQuestionPaperLink(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formDescription">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Enter description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formDetailsReportLink">
              <Form.Label>Details Report Link</Form.Label>
              <Form.Control
                type="url"
                placeholder="Enter details report link"
                value={detailsReportLink}
                onChange={(e) => setDetailsReportLink(e.target.value)}
                required
              />
            </Form.Group>

            <Button variant="success" type="submit" disabled={loading}>
              {loading ? 'Sharing...' : 'Share Now'}
            </Button>
          </Form>
        )}

        <h2 className="mt-5">Shared Data</h2>
        {sharedData.length > 0 ? (
          <Table bordered hover className="mt-3">
            <thead>
              <tr>
                <th>Title</th>
                <th>Video Link</th>
                <th>Question Paper Link</th>
                <th>Description</th>
                <th>Details Report Link</th> {/* New column for details report */}
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sharedData.map((item) => (
                <tr key={item.id}>
                  <td>{item.title}</td>
                  <td>
                    <a href={item.videoLink} target="_blank" rel="noopener noreferrer">
                      {item.videoLink}
                    </a>
                  </td>
                  <td>
                    <a href={item.questionPaperLink} target="_blank" rel="noopener noreferrer">
                      {item.questionPaperLink}
                    </a>
                  </td>
                  <td>{item.description}</td>
                  <td>
                    <a href={item.detailsReportLink} target="_blank" rel="noopener noreferrer">
                      {item.detailsReportLink}
                    </a>
                  </td>
                  <td>
                    <div className="d-flex justify-content-center">
                      <Button
                        variant="warning"
                        size="sm"
                        className="me-2 px-4 py-2 text-white fw-bold"
                        style={{ borderRadius: '5px', fontSize: '0.9rem' }}
                        onClick={() => handleEdit(item)}
                      >
                        Edit
                      </Button>
                      <Button
                        variant="danger"
                        size="sm"
                        className="px-4 py-2 text-white fw-bold"
                        style={{ borderRadius: '5px', fontSize: '0.9rem' }}
                        onClick={() => handleDelete(item.id)}
                      >
                        Delete
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          <p className="text-muted mt-3">No data shared yet.</p>
        )}
      </Container>
    </div>
  );
};

export default SharePage;
