import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Table, Button, Modal, Form } from 'react-bootstrap';
import { ref, get, set } from 'firebase/database';
import { database } from '../firebaseConfig';
import { getAuth } from 'firebase/auth';

const ControlPage = () => {
  const [userData, setUserData] = useState([]);
  const [evaluatedFile, setEvaluatedFile] = useState(null);
  const [detailsReportFile, setDetailsReportFile] = useState(null); // New state for Details Report
  const [selectedUser, setSelectedUser] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const auth = getAuth();

  useEffect(() => {
    // Fetch all shared data with user-specific answers
    const fetchUserData = async () => {
      try {
        const snapshot = await get(ref(database, 'shared_data/'));
        const data = snapshot.val();
        const dataList = [];

        for (let id in data) {
          if (data[id].answers) {
            for (let answerId in data[id].answers) {
              dataList.push({
                sharedDataId: id,
                answerId,
                ...data[id],
                ...data[id].answers[answerId],
              });
            }
          }
        }

        setUserData(dataList);
      } catch (error) {
        console.error('Error fetching user data from Firebase:', error);
      }
    };

    fetchUserData();
  }, []);

  const handleShowUploadModal = (user) => {
    setSelectedUser(user);
    setShowUploadModal(true);
  };

  const handleCloseUploadModal = () => {
    setShowUploadModal(false);
    setSelectedUser(null);
    setEvaluatedFile(null);
    setDetailsReportFile(null); // Reset the file inputs
  };

  const handleEvaluatedFileChange = (e) => {
    const file = e.target.files[0];
    setEvaluatedFile(file);
  };

  const handleDetailsReportFileChange = (e) => {
    const file = e.target.files[0];
    setDetailsReportFile(file);
  };

  const uploadEvaluatedAnswerAndDetailsReport = async () => {
    if ((!evaluatedFile && !detailsReportFile) || !selectedUser) {
      console.error('Missing files or selected user');
      return;
    }

    try {
      // Convert files to base64
      const evaluatedFileData = evaluatedFile ? await toBase64(evaluatedFile) : null;
      const detailsReportFileData = detailsReportFile ? await toBase64(detailsReportFile) : null;

      // Upload Evaluated Answer to GitHub
      let evaluatedFileLink = '';
      if (evaluatedFileData) {
        const responseEvaluated = await fetch(`https://api.github.com/repos/amreshbhuya/server/contents/evaluated_answers/${evaluatedFile.name}`, {
          method: 'PUT',
          headers: {
            'Authorization': `token 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`,
            'Accept': 'application/vnd.github.v3+json',
          },
          body: JSON.stringify({
            message: `Upload Evaluated Answer: ${evaluatedFile.name}`,
            content: evaluatedFileData,
          }),
        });

        if (!responseEvaluated.ok) {
          throw new Error('Error uploading evaluated answer file');
        }

        evaluatedFileLink = `https://raw.githubusercontent.com/amreshbhuya/server/main/evaluated_answers/${evaluatedFile.name}`;
      }

      // Upload Details Report to GitHub
      let detailsReportFileLink = '';
      if (detailsReportFileData) {
        const responseDetails = await fetch(`https://api.github.com/repos/amreshbhuya/server/contents/details_reports/${detailsReportFile.name}`, {
          method: 'PUT',
          headers: {
            'Authorization': `token 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`,
            'Accept': 'application/vnd.github.v3+json',
          },
          body: JSON.stringify({
            message: `Upload Details Report: ${detailsReportFile.name}`,
            content: detailsReportFileData,
          }),
        });

        if (!responseDetails.ok) {
          throw new Error('Error uploading details report file');
        }

        detailsReportFileLink = `https://raw.githubusercontent.com/amreshbhuya/server/main/details_reports/${detailsReportFile.name}`;
      }

      // Save links in Firebase
      await set(
        ref(database, `shared_data/${selectedUser.sharedDataId}/answers/${selectedUser.answerId}/evaluated_answer`),
        {
          fileLink: evaluatedFileLink,
          uploadedAt: new Date().toISOString(),
          evaluator: auth.currentUser ? auth.currentUser.email : 'Unknown',
        }
      );

      await set(
        ref(database, `shared_data/${selectedUser.sharedDataId}/answers/${selectedUser.answerId}/details_report`),
        {
          fileLink: detailsReportFileLink,
          uploadedAt: new Date().toISOString(),
          evaluator: auth.currentUser ? auth.currentUser.email : 'Unknown',
        }
      );

      console.log('Evaluated answer and details report uploaded successfully!');
      setEvaluatedFile(null);
      setDetailsReportFile(null);
      setShowUploadModal(false);
    } catch (err) {
      console.error('Error uploading evaluated answer or details report file:', err);
    }
  };

  const toBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result.split(',')[1]);
      reader.onerror = (error) => reject(error);
    });
  };

  return (
    <div className="control-page">
      <Container style={{ marginTop: '80px' }}>
        <h1 className="mt-4 text-center text-primary">Control Page</h1>
        <p className="text-center text-muted">Manage and review all uploaded answers and evaluate them.</p>

        <Row>
          <Col>
            <Table striped bordered hover responsive className="shadow-sm">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Email</th>
                  <th>Shared Data ID</th>
                  <th>Uploaded At</th>
                  <th>Answer File</th>
                  <th>Evaluated File</th>
                  <th>Details Report</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {userData.map((user, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{user.email}</td>
                    <td>{user.sharedDataId}</td>
                    <td>{user.uploadedAt ? new Date(user.uploadedAt).toLocaleString() : 'N/A'}</td>
                    <td>
                      <a href={user.fileLink} target="_blank" rel="noopener noreferrer">
                        Download Answer
                      </a>
                    </td>
                    <td>
                      {user.evaluated_answer ? (
                        <a href={user.evaluated_answer.fileLink} target="_blank" rel="noopener noreferrer">
                          Download Evaluated Answer
                        </a>
                      ) : (
                        'Not Uploaded'
                      )}
                    </td>
                    <td>
                      {user.details_report ? (
                        <a href={user.details_report.fileLink} target="_blank" rel="noopener noreferrer">
                          Download Details Report
                        </a>
                      ) : (
                        'Not Uploaded'
                      )}
                    </td>
                    <td>
                      {!user.evaluated_answer && (
                        <Button
                          variant="primary"
                          onClick={() => handleShowUploadModal(user)}
                        >
                          Upload Evaluated Answer & Report
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Col>
        </Row>
      </Container>

      {/* Modal for Uploading Evaluated Answer and Details Report */}
      <Modal
  show={showUploadModal}
  onHide={handleCloseUploadModal}
  size="lg"
  centered
  className="custom-modal"
>
  {/* Modal Header with Gradient Background */}
  <Modal.Header closeButton className="bg-gradient-custom text-white">
    <Modal.Title>Upload Evaluated Answer & Details Report</Modal.Title>
  </Modal.Header>

  {/* Modal Body with Clean Layout and Icons */}
  <Modal.Body>
    <div className="upload-section">
      <h5 className="text-muted mb-4">Please upload the following documents:</h5>

      {/* Evaluated Answer Section */}
      <div className="mb-4">
        <p className="upload-title">Evaluated Answer</p>
        <div className="file-input-container">
          <i className="bi bi-file-earmark-lock me-2 fs-4 text-info"></i>
          <Form.Group controlId="formFileEvaluated">
            <Form.Control
              type="file"
              onChange={handleEvaluatedFileChange}
              className="file-input"
            />
          </Form.Group>
        </div>
      </div>

      {/* Details Report Section */}
      <div className="mb-4">
        <p className="upload-title">Details Report</p>
        <div className="file-input-container">
          <i className="bi bi-file-earmark-text me-2 fs-4 text-info"></i>
          <Form.Group controlId="formFileDetailsReport">
            <Form.Control
              type="file"
              onChange={handleDetailsReportFileChange}
              className="file-input"
            />
          </Form.Group>
        </div>
      </div>
    </div>
  </Modal.Body>

  {/* Modal Footer with Animated Buttons */}
  <Modal.Footer className="d-flex justify-content-between">
    <Button
      variant="secondary"
      onClick={handleCloseUploadModal}
      className="btn-custom-close"
    >
      Close
    </Button>
    <Button
      variant="primary"
      onClick={uploadEvaluatedAnswerAndDetailsReport}
      className="btn-custom-upload"
    >
      <i className="bi bi-upload me-2"></i> Upload
    </Button>
  </Modal.Footer>
</Modal>

    </div>
  );
};

export default ControlPage;
