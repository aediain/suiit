import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import LoginPage from './components/login';
import AdminPage from './components/AdminPage';
import StudentPage from './components/StudentPage';
import ManageUserPage from './components/ManageUsersPage';
import AShare from './components/AShare';
import ControlPage from './components/control';
import FeedbackControlPage from './components/FeedbackControl';
import PrivateRoute from './PrivateRoute'; // Import the updated PrivateRoute

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/login" element={<LoginPage />} />
        
        {/* Admin routes protected by PrivateRoute */}
        <Route path="/admin" element={<PrivateRoute adminOnly={true}><AdminPage /></PrivateRoute>} />
        <Route path="/admin/users" element={<PrivateRoute adminOnly={true}><ManageUserPage /></PrivateRoute>} />
        <Route path="/admin/share" element={<PrivateRoute adminOnly={true}><AShare /></PrivateRoute>} />
        <Route path="/admin/control" element={<PrivateRoute adminOnly={true}><ControlPage /></PrivateRoute>} />
        <Route path="/admin/FeedbackControl" element={<PrivateRoute adminOnly={true}><FeedbackControlPage /></PrivateRoute>} />

        {/* Student routes */}
        <Route path="/student" element={<PrivateRoute><StudentPage /></PrivateRoute>} />
      </Routes>
    </Router>
  );
};

export default App;
