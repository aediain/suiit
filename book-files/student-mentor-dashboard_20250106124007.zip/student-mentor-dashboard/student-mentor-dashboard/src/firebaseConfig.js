import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";
import { getStorage } from "firebase/storage";
import { getAuth, GoogleAuthProvider,signOut } from 'firebase/auth';
import { getMessaging } from "firebase/messaging"; // Import messaging

const firebaseConfig = {
  apiKey: "AIzaSyDnNC1_wj6hnaMJ4txEnhH2bkca4n0Xxfc",
  authDomain: "project1-434ce.firebaseapp.com",
  projectId: "project1-434ce",
  storageBucket: "project1-434ce.firebasestorage.app",
  messagingSenderId: "279995427710",
  appId: "1:279995427710:web:03c2b8edd1a6c2cd0c212f",
  measurementId: "G-5GB8HPQVCB"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);
const provider = new GoogleAuthProvider();
const storage = getStorage(app);
const messaging = getMessaging(app); 

export { database, storage, auth, provider, messaging,signOut }; 
