import React, { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { ref, get } from 'firebase/database';
import { database } from './firebaseConfig'; // Import your Firebase database configuration

const PrivateRoute = ({ children, adminOnly = false }) => {
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        // Fetch user data from the database
        const userRef = ref(database, `users/${currentUser.uid}`);
        get(userRef)
          .then((snapshot) => {
            if (snapshot.exists()) {
              const userData = snapshot.val();
              setUser(currentUser);
              setIsAdmin(userData.isAdmin || false); // Use the 'isAdmin' field from the database
            } else {
              // If user data doesn't exist, assume not an admin
              setUser(currentUser);
              setIsAdmin(false);
            }
            setLoading(false);
          })
          .catch((error) => {
            console.error("Error fetching user data", error);
            setLoading(false);
          });
      } else {
        setUser(null);
        setIsAdmin(false);
        setLoading(false);
      }
    });

    return unsubscribe;
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!user) {
    // Redirect to login if no user is authenticated
    return <Navigate to="/login" />;
  }

  if (adminOnly && !isAdmin) {
    // Redirect to student page if user is not an admin but trying to access admin-only routes
    return <Navigate to="/student" />;
  }

  return children;
};

export default PrivateRoute;
